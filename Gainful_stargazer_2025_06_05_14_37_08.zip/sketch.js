let player;

let trash = [];

let animals = [];

let score = 0;

function setup() {

  createCanvas(600, 400);

  player = new Player();

  // Criando lixo

  for (let i = 0; i < 5; i++) {

    trash.push(new Trash());

  }

  // Criando animais

  for (let i = 0; i < 3; i++) {

    animals.push(new Animal());

  }

}

function draw() {

  background(100, 200, 100);

  fill(255);

  textSize(20);

  text("Pontuação: " + score, 10, 25);

  player.update();

  player.show();

  for (let t of trash) {

    t.show();

    if (player.collect(t)) {

      t.respawn();

      score += 10;

    }

  }

  for (let a of animals) {

    a.move();

    a.show();

    if (player.hit(a)) {

      score -= 5;

      a.respawn();

    }

  }

}

function keyPressed() {

  if (keyCode === LEFT_ARROW) player.move(-1, 0);

  if (keyCode === RIGHT_ARROW) player.move(1, 0);

  if (keyCode === UP_ARROW) player.move(0, -1);

  if (keyCode === DOWN_ARROW) player.move(0, 1);

}

// Classes

class Player {

  constructor() {

    this.x = width / 2;

    this.y = height / 2;

    this.size = 30;

  }

  move(dx, dy) {

    this.x += dx * 10;

    this.y += dy * 10;

    this.x = constrain(this.x, 0, width);

    this.y = constrain(this.y, 0, height);

  }

  update() {

    // Nada extra por enquanto

  }

  show() {

    fill(0, 100, 255);

    ellipse(this.x, this.y, this.size);

  }

  collect(t) {

    return dist(this.x, this.y, t.x, t.y) < (this.size + t.size) / 2;

  }

  hit(a) {

    return dist(this.x, this.y, a.x, a.y) < (this.size + a.size) / 2;

  }

}

class Trash {

  constructor() {

    this.respawn();

    this.size = 20;

  }

  respawn() {

    this.x = random(50, width - 50);

    this.y = random(50, height - 50);

  }

  show() {

    fill(0);

    rect(this.x, this.y, this.size, this.size);

  }

}

class Animal {

  constructor() {

    this.respawn();

    this.size = 25;

  }

  move() {

    this.x += random(-2, 2);

    this.y += random(-2, 2);

    this.x = constrain(this.x, 0, width);

    this.y = constrain(this.y, 0, height);

  }

  respawn() {

    this.x = random(50, width - 50);

    this.y = random(50, height - 50);

  }

  show() {

    fill(150, 75, 0);

    ellipse(this.x, this.y, this.size);

  }

}

